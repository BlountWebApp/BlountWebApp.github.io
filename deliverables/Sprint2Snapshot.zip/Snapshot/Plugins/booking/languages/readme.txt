There are 2 types of Booking Calendar translations.

1) One list of translations located at WordPress repository: https://translate.wordpress.org/projects/wp-plugins/booking/
Please note, these translations at your website should be located at: "../wp-content/languages/plugins/" folder.


2) Another list of translations located at the Booking Calendar website.
You can download the original PO translations files at Booking Calendar website from here: http://wpbookingcalendar.com/download/languages/languages.zip
Please note, these translations at your website should be located at: "../wp-content/plugins/{Booking Calendar Folder}/languages/" folder.


By  default Booking Calendar plugin try to use translations from "../wp-content/languages/plugins/",
if failed (not exist),  then  try to use translations from "../wp-content/plugins/{Booking Calendar Folder}/languages/" folder.
This behavior is possible to change at the Booking > Settings General page in the Translation section.


---------------------------------------------------------------------------------------------------------------------------------

You can check instruction how to make or update translations files at this page:
http://wpbookingcalendar.com/faq/make-translation-of-wp-plugin/


More info about translations or using several languages in plugin, please check at FAQ here https://wpbookingcalendar.com/faq/#translation