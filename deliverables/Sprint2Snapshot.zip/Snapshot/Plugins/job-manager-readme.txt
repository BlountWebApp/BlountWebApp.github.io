Notes:
Remote Position -> is standing

TODO: 
Job Type -> offer or request
--Full Time: Request
--Part Time: Offer

EDIT THESE:
?
include/class-job-dashboard-shortcode
include/class-wp-job-manager-email-notifications
admin/
emails/

✔️
include/class-wp-job-manager-post-types.php
include/forms/class-wp-job-manager-form-submit-job.php
wp-job-manager/wp-job-manager-functions.php