-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 18, 2025 at 01:14 PM
-- Server version: 8.0.41
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brahe_wjrx1`
--

-- --------------------------------------------------------

--
-- Table structure for table `zinr_bookingdates`
--

CREATE TABLE `zinr_bookingdates` (
  `booking_dates_id` bigint UNSIGNED NOT NULL,
  `booking_id` bigint UNSIGNED NOT NULL,
  `booking_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `approved` bigint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `zinr_bookingdates`
--

INSERT INTO `zinr_bookingdates` (`booking_dates_id`, `booking_id`, `booking_date`, `approved`) VALUES
(1, 1, '2025-02-15 00:00:00', 0),
(2, 1, '2025-02-16 00:00:00', 0),
(3, 1, '2025-02-17 00:00:00', 0),
(4, 2, '2025-02-17 14:30:01', 0),
(5, 2, '2025-02-17 15:30:02', 0),
(6, 3, '2025-02-17 14:30:01', 0),
(7, 3, '2025-02-17 15:30:02', 0),
(8, 4, '2025-02-17 14:30:01', 0),
(9, 4, '2025-02-17 15:30:02', 0),
(10, 5, '2025-02-18 10:00:01', 1),
(11, 5, '2025-02-18 10:15:02', 1),
(12, 6, '2025-02-18 10:30:01', 1),
(13, 6, '2025-02-18 12:00:02', 1),
(14, 7, '2025-02-18 10:00:01', 1),
(15, 7, '2025-02-18 10:15:02', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `zinr_bookingdates`
--
ALTER TABLE `zinr_bookingdates`
  ADD PRIMARY KEY (`booking_dates_id`),
  ADD UNIQUE KEY `booking_id_dates` (`booking_id`,`booking_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `zinr_bookingdates`
--
ALTER TABLE `zinr_bookingdates`
  MODIFY `booking_dates_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
