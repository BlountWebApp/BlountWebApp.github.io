-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 18, 2025 at 01:13 PM
-- Server version: 8.0.41
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brahe_wjrx1`
--

-- --------------------------------------------------------

--
-- Table structure for table `zinr_booking`
--

CREATE TABLE `zinr_booking` (
  `booking_id` bigint UNSIGNED NOT NULL,
  `booking_options` text COLLATE utf8mb4_unicode_520_ci,
  `trash` bigint NOT NULL DEFAULT '0',
  `is_trash` datetime DEFAULT NULL,
  `sync_gid` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `is_new` bigint NOT NULL DEFAULT '1',
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `sort_date` datetime DEFAULT NULL,
  `modification_date` datetime DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `form` text COLLATE utf8mb4_unicode_520_ci,
  `hash` text COLLATE utf8mb4_unicode_520_ci,
  `booking_type` bigint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `zinr_booking`
--

INSERT INTO `zinr_booking` (`booking_id`, `booking_options`, `trash`, `is_trash`, `sync_gid`, `is_new`, `status`, `sort_date`, `modification_date`, `creation_date`, `form`, `hash`, `booking_type`) VALUES
(1, 'a:1:{s:19:\"booking_meta_locale\";s:5:\"en_US\";}', 1, '2025-02-14 20:06:01', '', 1, '', '2025-02-15 00:00:00', '2025-02-13 11:18:39', '2025-02-13 17:18:39', 'text^name1^Jony~text^secondname1^Smith~text^email1^example-free@wpbookingcalendar.com~text^phone1^458-77-77~textarea^details1^Reserve a room with sea view', '21e6dd09a1ab40c2345fe90ddba09a66', 1),
(2, NULL, 1, '2025-02-15 02:27:27', '449n4ti4dqhoes81ijdcjdveou', 1, '', '2025-02-17 14:30:01', '2025-02-14 20:17:31', '2025-02-15 02:17:31', 'selectbox-one^rangetime1^14:30 - 15:30~text^name1^OB 1~textarea^details1^', 'fe48c99731e57fcb609cc9af20868e24', 1),
(3, NULL, 1, '2025-02-15 02:27:23', '6t2qc8lj4qp75ub1kk2vhnea2b', 1, '', '2025-02-17 14:30:01', '2025-02-14 20:17:31', '2025-02-15 02:17:31', 'selectbox-one^rangetime1^14:30 - 15:30~text^name1^OB 2~textarea^details1^', '1f6e2c6884e70549e5835a87ee4798ec', 1),
(4, NULL, 1, '2025-02-14 22:42:34', '3c07udu64u82t0c5b7m61omjh7', 1, '', '2025-02-17 14:30:01', '2025-02-14 20:17:31', '2025-02-15 02:17:31', 'selectbox-one^rangetime1^14:30 - 15:30~text^name1^Tuomey 1~textarea^details1^', '60880f3e6c5d1c2420dd2f17b46a3f7d', 1),
(5, NULL, 0, NULL, '', 0, '', '2025-02-18 10:00:01', '2025-02-15 02:59:59', '2025-02-15 08:59:59', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '49a66e167a778d690c1934cda25c1016', 1),
(6, NULL, 0, NULL, '', 0, '', '2025-02-18 10:30:01', '2025-02-15 03:02:14', '2025-02-15 09:02:14', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^10:30~selectbox-one^starttime_val1^10:30 AM~text^name1^Jane~text^name_val1^Jane~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '8780847a272cb598ec8cd78f6bcba01d', 1),
(7, NULL, 0, NULL, '', 0, '', '2025-02-18 10:00:01', '2025-02-15 03:05:48', '2025-02-15 09:05:48', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^James~text^name_val1^James~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'bdbded02fda1a0bed2aa85418ea13352', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `zinr_booking`
--
ALTER TABLE `zinr_booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `zinr_booking`
--
ALTER TABLE `zinr_booking`
  MODIFY `booking_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
