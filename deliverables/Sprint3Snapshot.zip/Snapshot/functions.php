<?php
/**
 * Student Note: 
 * 		This file is pulled from the site's theme.
 * 		Purpose: To override certain features of the WP Job Manager Plugin.
 * 		Navigation in cPanel: public_html/wp-content/themes/as-wildcat/functions.php
 */

/**
 * wildcat functions and definitions
 *
 * @package wildcat
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// wildcat's includes directory.
$wildcat_inc_dir = 'inc';

// Array of files to include.
$wildcat_includes = array(
	'/theme-settings.php',                  // Initialize theme default settings.
	'/setup.php',                           // Theme setup and custom theme supports.
	'/widgets.php',                         // Register widget area.
	'/enqueue.php',                         // Enqueue scripts and styles.
	'/template-tags.php',                   // Custom template tags for this theme.
	'/pagination.php',                      // Custom pagination for this theme.
	'/hooks.php',                           // Custom hooks.
	'/extras.php',                          // Custom functions that act independently of the theme templates.
	'/customizer.php',                      // Customizer additions.
	'/custom-header.php',                 // Custom header image
	'/class-wp-bootstrap-navwalker.php',    // Load custom WordPress nav walker. Trying to get deeper navigation? Check out: https://github.com/wildcat/wildcat/issues/567.
	'/editor.php',                          // Load Editor functions.
	'/block-editor.php',                    // Load Block Editor functions.
	'/deprecated.php',                      // Load deprecated functions.
);

// Load WooCommerce functions if WooCommerce is activated.
if ( class_exists( 'WooCommerce' ) ) {
	$wildcat_includes[] = '/woocommerce.php';
}

// Load Jetpack compatibility file if Jetpack is activiated.
if ( class_exists( 'Jetpack' ) ) {
	$wildcat_includes[] = '/jetpack.php';
}


// Include files.
foreach ( $wildcat_includes as $file ) {
	require_once get_theme_file_path( $wildcat_inc_dir . $file );
}

// Override of Job lingo text to Ride lingo text
add_filter( 'gettext', 'custom_override_job_manager_strings', 10, 3 );
function custom_override_job_manager_strings( $translated_text, $text, $domain ) {
    if ( $domain === 'wp-job-manager' && $text === 'Draft was saved. Job listing drafts can be resumed from the <a href="%s">job dashboard</a>.' ) {
        return 'Draft was saved. Ride listing drafts can be resumed from the <a href="%s">ride dashboard</a>.';
    }
    return $translated_text;
}

// Override of Job lingo text to Ride lingo text
add_filter( 'gettext', 'custom_override_job_manager_strings2', 10, 3 );
function custom_override_job_manager_strings2( $translated_text, $text, $domain ) {
    if ( $domain === 'wp-job-manager' && $text === 'Choose job type&hellip;' ) {
        return 'Choose ride type&hellip;';
    }
    return $translated_text;
}

// Saves and stores the custom fields added to the ride offer/request form. 
// This lets you pull this information to display on a single job listing.
add_filter('job_manager_update_job_data', 'save_custom_job_fields', 10, 2);

function save_custom_job_fields($job_data, $post_id) {
    // For ride_date field
    if (isset($_POST['ride_date'])) {
        update_post_meta($post_id, '_ride_date', sanitize_text_field($_POST['ride_date']));
    }
    
    // For pickup_location field
    if (isset($_POST['pickup_location'])) {
        update_post_meta($post_id, '_pickup_location', sanitize_text_field($_POST['pickup_location']));
    }
    
    // For contact_method field
    if (isset($_POST['contact_method'])) {
        update_post_meta($post_id, '_contact_method', sanitize_text_field($_POST['contact_method']));
    }
    
    return $job_data;
}

// Sends email to user who's posted a ride offer/request stating it has been approved and is visible to other users.
// This function is uploaded to the Code Snippets plugin (which was used because it was listed in WP Job Manager documentation)
// This function has been listed here for documentation purposes only.
function listing_published_send_email($post_id) {
	if( 'job_listing' != get_post_type( $post_id ) ) {
	  return;
	}
	$post = get_post($post_id);
	$author = get_userdata($post->post_author);
   
	$message = "
	  Hi ".$author->display_name.",
	  Your listing, ".$post->post_title.", has just been approved at ".get_permalink( $post_id ).".";
	wp_mail($author->user_email, "Your Ride Listing is Online", $message);
  }
  add_action('pending_to_publish', 'listing_published_send_email');
  add_action('pending_payment_to_publish', 'listing_published_send_email');

