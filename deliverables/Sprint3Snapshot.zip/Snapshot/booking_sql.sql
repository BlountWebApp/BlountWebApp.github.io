-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 22, 2025 at 10:26 AM
-- Server version: 8.0.42
-- PHP Version: 8.3.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brahe_wjrx1`
--

-- --------------------------------------------------------

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`brahe`@`localhost` PROCEDURE `create_recurring_booking` (IN `repeat_days` TEXT, IN `selected_room` VARCHAR(25), IN `duration_time` VARCHAR(25), IN `duration_interval` VARCHAR(25), IN `start_time` VARCHAR(25), IN `start_time_val` VARCHAR(25), IN `first_name` VARCHAR(25), IN `last_name` VARCHAR(25), IN `email` VARCHAR(30), IN `first_day` DATE, IN `last_day` DATE)   BEGIN
SET @mod_date = CURRENT_TIMESTAMP;

CREATE TEMPORARY TABLE temp_booking (
    `is_new` bigint DEFAULT 1,
    `start_date` datetime,
    `modification_date` datetime,
    `form` text,
    `hash` text
);
SET @stmt = CONCAT('INSERT INTO temp_booking (`start_date`)
WITH RECURSIVE date_range AS (
    SELECT ''', first_day, ''' AS start_date
    UNION ALL
    SELECT DATE_ADD(start_date, INTERVAL 1 DAY) FROM date_range
    WHERE start_date < ''', last_day,
''')
SELECT `start_date` FROM date_range WHERE WEEKDAY(start_date) IN ', repeat_days, ';');
PREPARE stmt from @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

UPDATE temp_booking
SET `start_date` = ADDTIME(`start_date`, CONCAT(start_time, ':01')),
`modification_date` = @mod_date, `form` = CONCAT( 'selectbox-one^seminarroom1^', selected_room, '~selectbox-one^seminarroom_val1^', selected_room, 
        '~selectbox-one^durationtime1^', duration_time, '~selectbox-one^durationtime_val1^', duration_interval, 
        '~selectbox-one^starttime1^', start_time, '~selectbox-one^starttime_val1^', start_time_val, 
        '~text^name1^', first_name, '~text^name_val1^', first_name, 
        '~text^secondname1^', last_name, '~text^secondname_val1^', last_name,
        '~email^email1^', email, '~email^email_val1^', email ), `hash` = gen_booking_hash();
        
UPDATE temp_booking
SET `is_new` = 0 WHERE DATE(`start_date`) IN (SELECT DATE(`booking_date`) FROM zinr_bookingdates);

INSERT INTO zinr_booking (`is_new`, `sort_date`, `modification_date`, `form`, `hash`)
SELECT `is_new`, `start_date`, `modification_date`, `form`, `hash` FROM temp_booking;

INSERT INTO zinr_bookingdates (`booking_id`, `booking_date`, `approved`)
SELECT `booking_id`, `sort_date`, 1 FROM zinr_booking WHERE `modification_date` = @mod_date;

INSERT INTO zinr_bookingdates (`booking_id`, `booking_date`, `approved`)
SELECT `booking_id`, ADDTIME(`sort_date`, CONCAT(duration_time, ':01')), 1 FROM zinr_booking WHERE `modification_date` = @mod_date;

DROP TEMPORARY TABLE IF EXISTS temp_booking;
END$$

--
-- Functions
--
CREATE DEFINER=`brahe`@`localhost` FUNCTION `gen_booking_hash` () RETURNS TEXT CHARSET utf8mb4 COMMENT 'Generate a hash for zinr_booking' RETURN MD5(CONCAT(UNIX_TIMESTAMP(), '_', FLOOR(RAND()*999001)+1000))$$

DELIMITER ;
-- --------------------------------------------------------

--
-- Table structure for table `zinr_booking`
--

CREATE TABLE `zinr_booking` (
  `booking_id` bigint UNSIGNED NOT NULL,
  `booking_options` text COLLATE utf8mb4_unicode_520_ci,
  `trash` bigint NOT NULL DEFAULT '0',
  `is_trash` datetime DEFAULT NULL,
  `sync_gid` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `is_new` bigint NOT NULL DEFAULT '1',
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `sort_date` datetime DEFAULT NULL,
  `modification_date` datetime DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `form` text COLLATE utf8mb4_unicode_520_ci,
  `hash` text COLLATE utf8mb4_unicode_520_ci,
  `booking_type` bigint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `zinr_booking`
--

INSERT INTO `zinr_booking` (`booking_id`, `booking_options`, `trash`, `is_trash`, `sync_gid`, `is_new`, `status`, `sort_date`, `modification_date`, `creation_date`, `form`, `hash`, `booking_type`) VALUES
(1, 'a:1:{s:19:\"booking_meta_locale\";s:5:\"en_US\";}', 1, '2025-02-14 20:06:01', '', 1, '', '2025-02-15 00:00:00', '2025-02-13 11:18:39', '2025-02-13 17:18:39', 'text^name1^Jony~text^secondname1^Smith~text^email1^example-free@wpbookingcalendar.com~text^phone1^458-77-77~textarea^details1^Reserve a room with sea view', '21e6dd09a1ab40c2345fe90ddba09a66', 1),
(2, NULL, 1, '2025-02-15 02:27:27', '449n4ti4dqhoes81ijdcjdveou', 1, '', '2025-02-17 14:30:01', '2025-02-14 20:17:31', '2025-02-15 02:17:31', 'selectbox-one^rangetime1^14:30 - 15:30~text^name1^OB 1~textarea^details1^', 'fe48c99731e57fcb609cc9af20868e24', 1),
(3, NULL, 1, '2025-02-15 02:27:23', '6t2qc8lj4qp75ub1kk2vhnea2b', 1, '', '2025-02-17 14:30:01', '2025-02-14 20:17:31', '2025-02-15 02:17:31', 'selectbox-one^rangetime1^14:30 - 15:30~text^name1^OB 2~textarea^details1^', '1f6e2c6884e70549e5835a87ee4798ec', 1),
(4, NULL, 1, '2025-02-14 22:42:34', '3c07udu64u82t0c5b7m61omjh7', 1, '', '2025-02-17 14:30:01', '2025-02-14 20:17:31', '2025-02-15 02:17:31', 'selectbox-one^rangetime1^14:30 - 15:30~text^name1^Tuomey 1~textarea^details1^', '60880f3e6c5d1c2420dd2f17b46a3f7d', 1),
(5, NULL, 0, NULL, '', 0, '', '2025-02-18 10:00:01', '2025-02-15 02:59:59', '2025-02-15 08:59:59', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '49a66e167a778d690c1934cda25c1016', 1),
(6, NULL, 0, NULL, '', 0, '', '2025-02-18 10:30:01', '2025-02-15 03:02:14', '2025-02-15 09:02:14', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^10:30~selectbox-one^starttime_val1^10:30 AM~text^name1^Jane~text^name_val1^Jane~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '8780847a272cb598ec8cd78f6bcba01d', 1),
(7, NULL, 0, NULL, '', 0, '', '2025-02-18 10:00:01', '2025-02-15 03:05:48', '2025-02-15 09:05:48', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^James~text^name_val1^James~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'bdbded02fda1a0bed2aa85418ea13352', 1),
(8, NULL, 0, NULL, '', 1, '', '2025-03-25 10:00:01', '2025-03-21 00:09:24', '2025-03-21 05:09:24', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'dbe1323a379d4912cfb1ec0a26bd4d9f', 1),
(9, NULL, 0, NULL, '', 1, '', '2025-03-24 10:00:01', '2025-03-21 19:50:05', '2025-03-22 00:50:05', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^Jane~text^name_val1^Jane~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '109c229fbd7960f0deb1f7e5dc6a5e92', 1),
(10, NULL, 0, NULL, '', 1, '', '2025-03-21 15:30:01', '2025-03-21 20:02:04', '2025-03-22 01:02:04', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^15:30~selectbox-one^starttime_val1^3:30 PM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '44c71eb739a3a4e11f317d96cc41d2a2', 1),
(11, NULL, 0, NULL, '', 0, '', '2025-03-24 10:00:01', '2025-03-22 03:42:36', '2025-03-22 08:42:36', 'selectbox-one^seminarroom1^OB 1007~selectbox-one^seminarroom_val1^OB 1007~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^Jane~text^name_val1^Jane~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'ec15264f38863725238ae2dee9af481e', 1),
(12, NULL, 0, NULL, '', 1, '', '2025-03-24 11:00:01', '2025-03-23 01:06:33', '2025-03-23 06:06:33', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^11:00~selectbox-one^starttime_val1^11:00 AM~text^name1^Hannah~text^name_val1^Hannah~text^secondname1^Bray~text^secondname_val1^Bray~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '10c3bbad6641698e94e3c520e3c38f0b', 1),
(13, NULL, 0, NULL, '', 1, '', '2025-03-26 10:00:01', '2025-03-23 17:58:26', '2025-03-23 22:58:26', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^J~text^name_val1^J~text^secondname1^D~text^secondname_val1^D~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'd2bbe50c3d7ff20131f9cc057b05cf18', 1),
(14, NULL, 0, NULL, '', 1, '', '2025-03-24 15:00:01', '2025-03-24 17:18:32', '2025-03-24 22:18:32', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^15:00~selectbox-one^starttime_val1^3:00 PM~text^name1^Hannah~text^name_val1^Hannah~text^secondname1^Bray~text^secondname_val1^Bray~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'a347251da58cae6ed7087b2fdc80af16', 1),
(15, NULL, 0, NULL, '', 0, '', '2025-03-25 10:00:01', '2025-03-25 03:38:59', '2025-03-25 08:38:59', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '055aaeaa0a6fa303b80fe1b90856c7be', 1),
(16, NULL, 0, NULL, '', 0, '', '2025-03-25 15:00:01', '2025-03-25 03:39:39', '2025-03-25 08:39:39', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^starttime1^15:00~selectbox-one^starttime_val1^3:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '870542811404e30f226de70920d9db68', 1),
(17, NULL, 0, NULL, '', 0, '', '2025-03-25 12:00:01', '2025-03-25 03:40:47', '2025-03-25 08:40:47', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^starttime1^12:00~selectbox-one^starttime_val1^12:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'fc313257bb68aea7441f61ebd9d458d8', 1),
(18, NULL, 0, NULL, '', 0, '', '2025-03-27 13:30:01', '2025-03-27 18:21:34', '2025-03-27 23:21:34', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^13:30~selectbox-one^starttime_val1^1:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '4b98ece6f22f96b10599b2a1455d3c1a', 1),
(19, NULL, 0, NULL, '', 1, '', '2025-03-27 14:00:01', '2025-03-27 18:22:20', '2025-03-27 23:22:20', 'selectbox-one^seminarroom1^OB 1007~selectbox-one^seminarroom_val1^OB 1007~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^14:00~selectbox-one^starttime_val1^2:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'be9907b1a74c527ef5a7cc7691eff4d2', 1),
(20, NULL, 0, NULL, '', 0, '', '2025-03-27 14:00:01', '2025-03-27 18:22:57', '2025-03-27 23:22:57', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^14:00~selectbox-one^starttime_val1^2:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '6d06ba7bad86fa624592ce0222c9d64b', 1),
(21, NULL, 0, NULL, '', 1, '', '2025-03-27 13:30:01', '2025-03-27 18:23:50', '2025-03-27 23:23:50', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^13:30~selectbox-one^starttime_val1^1:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'b4cde687c0d2f8f3f83daf7a1d4f1167', 1),
(22, NULL, 1, '2025-03-27 18:24:25', '', 1, '', '2025-03-27 14:30:01', '2025-03-27 18:24:11', '2025-03-27 23:24:11', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^14:30~selectbox-one^starttime_val1^2:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'f9b493c54fd334fb1f7ce7047bf7e72a', 1),
(23, NULL, 0, NULL, '', 1, '', '2025-03-27 15:00:01', '2025-03-27 18:25:06', '2025-03-27 23:25:06', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^15:00~selectbox-one^starttime_val1^3:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '2eb790173cdba02f7000a0584b18b31b', 1),
(24, NULL, 0, NULL, '', 1, '', '2025-03-28 15:30:01', '2025-03-27 18:43:24', '2025-03-27 23:43:24', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^15:30~selectbox-one^starttime_val1^3:30 PM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^john.doe@johndoe.come~email^email_val1^john.doe@johndoe.come', 'bdfa83b0f71ac0cc4438349182c7eecc', 1),
(25, NULL, 0, NULL, '', 1, '', '2025-03-28 13:30:01', '2025-03-27 19:17:21', '2025-03-28 00:17:21', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^13:30~selectbox-one^starttime_val1^1:30 PM~text^name1^Andrs~text^name_val1^Andrs~text^secondname1^AAAC~text^secondname_val1^AAAC~email^email1^aaaguilar1@crimson.ua.edu~email^email_val1^aaaguilar1@crimson.ua.edu', 'b74ca630189f1a1b8ac67ae779c2b5dd', 1),
(26, NULL, 0, NULL, '', 1, '', '2025-04-01 10:00:01', '2025-03-30 20:43:34', '2025-03-31 01:43:34', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'd093a29c5ea8142c725454559a23a26b', 1),
(27, NULL, 0, NULL, '', 1, '', '2025-04-01 11:00:01', '2025-03-30 20:50:24', '2025-03-31 01:50:24', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^00:15~selectbox-one^durationtime_val1^15 min~selectbox-one^starttime1^11:00~selectbox-one^starttime_val1^11:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '940de21dd292df72395857591d2858fd', 1),
(28, NULL, 0, NULL, '', 1, '', '2025-04-01 09:00:01', '2025-03-30 21:15:17', '2025-03-31 02:15:17', 'selectbox-one^seminarroom1^OB 1007~selectbox-one^seminarroom_val1^OB 1007~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^9:00~selectbox-one^starttime_val1^9:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'f3bf876a339264a1f657bd03433eb097', 1),
(29, NULL, 0, NULL, '', 0, '', '2025-04-01 09:00:01', '2025-03-31 11:44:38', '2025-03-31 16:44:38', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^9:00~selectbox-one^starttime_val1^9:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '4757c0180c60eb48a04b2601a821bb96', 1),
(30, NULL, 0, NULL, '', 1, '', '2025-04-03 09:00:01', '2025-03-31 11:44:38', '2025-03-31 16:44:38', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^9:00~selectbox-one^starttime_val1^9:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '3ceec9f16d743806d18f00a9511f2b78', 1),
(32, NULL, 0, NULL, '', 0, '', '2025-04-01 11:00:01', '2025-03-31 11:48:36', '2025-03-31 16:48:36', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^11:00~selectbox-one^starttime_val1^11:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '77632ceb2d43527547316154feb4b300', 1),
(33, NULL, 0, NULL, '', 0, '', '2025-04-03 11:00:01', '2025-03-31 11:48:36', '2025-03-31 16:48:36', 'selectbox-one^seminarroom1^OB 1012~selectbox-one^seminarroom_val1^OB 1012~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^11:00~selectbox-one^starttime_val1^11:00 AM~text^name1^John~text^name_val1^John~text^secondname1^Doe~text^secondname_val1^Doe~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'f52004bc79932f451d6dd4cdddd85bf9', 1),
(34, NULL, 0, NULL, '', 1, '', '2025-04-08 12:30:01', '2025-04-08 13:08:53', '2025-04-08 18:08:53', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^12:30~selectbox-one^starttime_val1^12:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'c08955692e0139b3f4ac816095249451', 1),
(35, NULL, 0, NULL, '', 1, '', '2025-04-10 12:30:01', '2025-04-08 13:08:53', '2025-04-08 18:08:53', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^12:30~selectbox-one^starttime_val1^12:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '888faa2f951bf0b7adc5160d77ac6a3e', 1),
(36, NULL, 0, NULL, '', 1, '', '2025-04-15 12:30:01', '2025-04-08 13:08:53', '2025-04-08 18:08:53', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^12:30~selectbox-one^starttime_val1^12:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '5248477c8c005acb9b5b9e440eb14b6e', 1),
(37, NULL, 0, NULL, '', 1, '', '2025-04-17 12:30:01', '2025-04-08 13:08:53', '2025-04-08 18:08:53', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^12:30~selectbox-one^starttime_val1^12:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '4b689a5cfa96c67f799fa59e28a4b74d', 1),
(41, NULL, 0, NULL, '', 1, '', '2025-04-13 11:30:01', '2025-04-13 16:30:51', '2025-04-13 21:30:51', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^11:30~selectbox-one^starttime_val1^11:30 AM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '319fc1a6c1449cc471b9b31529706428', 1),
(42, NULL, 0, NULL, '', 1, '', '2025-04-13 13:00:01', '2025-04-13 17:35:32', '2025-04-13 22:35:32', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^starttime1^13:00~selectbox-one^starttime_val1^1:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'b18017fc4cbcc78ce2b3f1e8619012e9', 1),
(43, NULL, 0, NULL, '', 1, '', '2025-04-13 15:00:01', '2025-04-13 17:36:29', '2025-04-13 22:36:29', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^starttime1^15:00~selectbox-one^starttime_val1^3:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '2a7ae778ec94826bc7a40ed504b2d51f', 1),
(44, NULL, 0, NULL, '', 1, '', '2025-04-13 17:30:01', '2025-04-13 22:40:02', '2025-04-14 03:40:02', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^17:30~selectbox-one^starttime_val1^5:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '79cca7a0fa5e20361564c5e7f01069be', 1),
(45, NULL, 0, NULL, '', 1, '', '2025-04-16 10:00:01', '2025-04-17 16:00:24', '2025-04-17 21:00:24', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^Admin~text^name_val1^Admin~text^secondname1^Booking Panel~text^secondname_val1^Booking Panel~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '66978c969e13df83874b96faad9e3456', 1),
(46, NULL, 0, NULL, '', 1, '', '2025-04-18 10:00:01', '2025-04-17 16:00:24', '2025-04-17 21:00:24', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^Admin~text^name_val1^Admin~text^secondname1^Booking Panel~text^secondname_val1^Booking Panel~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '85433ff43a57919a65b44c0e1b939019', 1),
(47, NULL, 0, NULL, '', 1, '', '2025-04-21 10:00:01', '2025-04-17 16:00:24', '2025-04-17 21:00:24', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^Admin~text^name_val1^Admin~text^secondname1^Booking Panel~text^secondname_val1^Booking Panel~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '1e2c1da00ec914d92000a543bdd065e3', 1),
(48, NULL, 0, NULL, '', 1, '', '2025-04-23 10:00:01', '2025-04-17 16:00:24', '2025-04-17 21:00:24', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^Admin~text^name_val1^Admin~text^secondname1^Booking Panel~text^secondname_val1^Booking Panel~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'a83cf5a7955e3725db9bf0aaac993980', 1),
(49, NULL, 0, NULL, '', 1, '', '2025-04-25 10:00:01', '2025-04-17 16:00:24', '2025-04-17 21:00:24', 'selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^Admin~text^name_val1^Admin~text^secondname1^Booking Panel~text^secondname_val1^Booking Panel~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '9f53036fce24181b7691e7b212239355', 1),
(52, NULL, 0, NULL, '', 1, '', '2025-04-18 11:30:01', '2025-04-18 01:42:27', '2025-04-18 06:42:27', 'selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^seminarroom1^OB 1007~selectbox-one^seminarroom_val1^OB 1007~selectbox-one^starttime1^11:30~selectbox-one^starttime_val1^11:30 AM~text^name1^Hannah~text^name_val1^Hannah~text^secondname1^Bray~text^secondname_val1^Bray~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'a12d0dc09396efbf701c7dcd68ec4262', 1),
(53, NULL, 0, NULL, '', 0, '', '2025-04-17 08:00:01', '2025-04-18 14:13:13', '2025-04-18 19:13:13', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^starttime1^8:00~selectbox-one^starttime_val1^8:00 AM~text^name1^Admin~text^name_val1^Admin~text^secondname1^Booking Panel~text^secondname_val1^Booking Panel~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '1325278ebd8149982b14d15f970da89d', 1),
(54, NULL, 0, NULL, '', 1, '', '2025-04-22 08:00:01', '2025-04-18 14:13:13', '2025-04-18 19:13:13', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^starttime1^8:00~selectbox-one^starttime_val1^8:00 AM~text^name1^Admin~text^name_val1^Admin~text^secondname1^Booking Panel~text^secondname_val1^Booking Panel~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'abb719e188a4aa0e391997fb674bac8c', 1),
(55, NULL, 0, NULL, '', 1, '', '2025-04-24 08:00:01', '2025-04-18 14:13:13', '2025-04-18 19:13:13', 'selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^starttime1^8:00~selectbox-one^starttime_val1^8:00 AM~text^name1^Admin~text^name_val1^Admin~text^secondname1^Booking Panel~text^secondname_val1^Booking Panel~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'cf36e26997b009e2902d87ddae603d89', 1),
(56, NULL, 0, NULL, '', 1, '', '2025-04-22 10:30:01', '2025-04-21 17:14:54', '2025-04-21 22:14:54', 'selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^seminarroom1^OB 1007~selectbox-one^seminarroom_val1^OB 1007~selectbox-one^starttime1^10:30~selectbox-one^starttime_val1^10:30 AM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '3452b0facdf0bf2ce58de90466d04acf', 1),
(57, NULL, 0, NULL, '', 1, '', '2025-04-21 13:00:01', '2025-04-21 17:16:55', '2025-04-21 22:16:55', 'selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^starttime1^13:00~selectbox-one^starttime_val1^1:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '16c37b4d7a01429da6dc20f7c0762664', 1),
(58, NULL, 0, NULL, '', 1, '', '2025-04-21 13:30:01', '2025-04-21 17:18:23', '2025-04-21 22:18:23', 'selectbox-one^durationtime1^01:30~selectbox-one^durationtime_val1^1.5 hr~selectbox-one^seminarroom1^OB 1007~selectbox-one^seminarroom_val1^OB 1007~selectbox-one^starttime1^13:30~selectbox-one^starttime_val1^1:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', 'fa32ecf795ae81e073043b6042ebc49f', 1),
(59, NULL, 0, NULL, '', 1, '', '2025-04-21 15:30:01', '2025-04-21 17:19:10', '2025-04-21 22:19:10', 'selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^seminarroom1^OB 1007~selectbox-one^seminarroom_val1^OB 1007~selectbox-one^starttime1^15:30~selectbox-one^starttime_val1^3:30 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '52bafce891232084b857b4840be6860e', 1),
(60, NULL, 0, NULL, '', 1, '', '2025-04-22 10:00:01', '2025-04-21 17:20:53', '2025-04-21 22:20:53', 'selectbox-one^durationtime1^00:30~selectbox-one^durationtime_val1^30 min~selectbox-one^seminarroom1^Main Hall~selectbox-one^seminarroom_val1^Main Hall~selectbox-one^starttime1^10:00~selectbox-one^starttime_val1^10:00 AM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '95815f8efe719e77c5f6c659ca40b3e4', 1),
(61, NULL, 0, NULL, '', 1, '', '2025-04-22 14:00:01', '2025-04-21 19:11:49', '2025-04-22 00:11:49', 'selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^starttime1^14:00~selectbox-one^starttime_val1^2:00 PM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^hlbray1@crimson.ua.edu~email^email_val1^hlbray1@crimson.ua.edu', '2b141dc63240457b4e2295c4d099ea29', 1),
(62, NULL, 0, NULL, '', 1, '', '2025-04-23 11:30:01', '2025-04-21 19:44:23', '2025-04-22 00:44:23', 'selectbox-one^durationtime1^01:00~selectbox-one^durationtime_val1^1 hr~selectbox-one^seminarroom1^OB 1006~selectbox-one^seminarroom_val1^OB 1006~selectbox-one^starttime1^11:30~selectbox-one^starttime_val1^11:30 AM~text^name1^H~text^name_val1^H~text^secondname1^B~text^secondname_val1^B~email^email1^cbnorman@crimson.ua.edu~email^email_val1^cbnorman@crimson.ua.edu', '957a8634e85980ae74330f37c68c4411', 1);

-- --------------------------------------------------------

--
-- Table structure for table `zinr_bookingdates`
--

CREATE TABLE `zinr_bookingdates` (
  `booking_dates_id` bigint UNSIGNED NOT NULL,
  `booking_id` bigint UNSIGNED NOT NULL,
  `booking_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `approved` bigint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `zinr_bookingdates`
--

INSERT INTO `zinr_bookingdates` (`booking_dates_id`, `booking_id`, `booking_date`, `approved`) VALUES
(1, 1, '2025-02-15 00:00:00', 0),
(2, 1, '2025-02-16 00:00:00', 0),
(3, 1, '2025-02-17 00:00:00', 0),
(4, 2, '2025-02-17 14:30:01', 0),
(5, 2, '2025-02-17 15:30:02', 0),
(6, 3, '2025-02-17 14:30:01', 0),
(7, 3, '2025-02-17 15:30:02', 0),
(8, 4, '2025-02-17 14:30:01', 0),
(9, 4, '2025-02-17 15:30:02', 0),
(10, 5, '2025-02-18 10:00:01', 1),
(11, 5, '2025-02-18 10:15:02', 1),
(12, 6, '2025-02-18 10:30:01', 1),
(13, 6, '2025-02-18 12:00:02', 1),
(14, 7, '2025-02-18 10:00:01', 1),
(15, 7, '2025-02-18 10:15:02', 1),
(16, 8, '2025-03-25 10:00:01', 0),
(17, 8, '2025-03-25 10:15:02', 0),
(18, 9, '2025-03-24 10:00:01', 0),
(19, 9, '2025-03-24 11:00:02', 0),
(20, 10, '2025-03-21 15:30:01', 0),
(21, 10, '2025-03-21 15:45:02', 0),
(22, 11, '2025-03-24 10:00:01', 1),
(23, 11, '2025-03-24 10:15:02', 1),
(24, 12, '2025-03-24 11:00:01', 0),
(25, 12, '2025-03-24 11:15:02', 0),
(26, 13, '2025-03-26 10:00:01', 0),
(27, 13, '2025-03-26 10:15:02', 0),
(28, 14, '2025-03-24 15:00:01', 0),
(29, 14, '2025-03-24 16:30:02', 0),
(30, 15, '2025-03-25 10:00:01', 1),
(31, 15, '2025-03-25 11:30:02', 1),
(32, 16, '2025-03-25 15:00:01', 1),
(33, 16, '2025-03-25 16:00:02', 1),
(34, 17, '2025-03-25 12:00:01', 1),
(35, 17, '2025-03-25 13:00:02', 1),
(36, 18, '2025-03-27 13:30:01', 1),
(37, 18, '2025-03-27 14:00:02', 1),
(38, 19, '2025-03-27 14:00:01', 0),
(39, 19, '2025-03-27 15:30:02', 0),
(40, 20, '2025-03-27 14:00:01', 1),
(41, 20, '2025-03-27 14:30:02', 1),
(42, 21, '2025-03-27 13:30:01', 0),
(43, 21, '2025-03-27 15:00:02', 0),
(44, 22, '2025-03-27 14:30:01', 0),
(45, 22, '2025-03-27 15:00:02', 0),
(46, 23, '2025-03-27 15:00:01', 0),
(47, 23, '2025-03-27 15:30:02', 0),
(48, 24, '2025-03-28 15:30:01', 0),
(49, 24, '2025-03-28 16:00:02', 0),
(50, 25, '2025-03-28 13:30:01', 0),
(51, 25, '2025-03-28 14:00:02', 0),
(52, 28, '2025-04-01 09:00:01', 1),
(53, 28, '2025-04-01 09:30:02', 1),
(54, 29, '2025-04-01 09:00:01', 1),
(55, 30, '2025-04-03 09:00:01', 1),
(57, 29, '2025-04-01 09:30:02', 1),
(58, 30, '2025-04-03 09:30:02', 1),
(60, 32, '2025-04-01 11:00:01', 1),
(61, 33, '2025-04-03 11:00:01', 1),
(63, 32, '2025-04-01 12:30:02', 1),
(64, 33, '2025-04-03 12:30:02', 1),
(65, 34, '2025-04-08 12:30:01', 1),
(66, 35, '2025-04-10 12:30:01', 1),
(67, 36, '2025-04-15 12:30:01', 1),
(68, 37, '2025-04-17 12:30:01', 1),
(72, 34, '2025-04-08 14:00:02', 1),
(73, 35, '2025-04-10 14:00:02', 1),
(74, 36, '2025-04-15 14:00:02', 1),
(75, 37, '2025-04-17 14:00:02', 1),
(79, 41, '2025-04-13 11:30:01', 0),
(80, 41, '2025-04-13 12:00:02', 0),
(81, 42, '2025-04-13 13:00:01', 0),
(82, 42, '2025-04-13 14:30:02', 0),
(83, 43, '2025-04-13 15:00:01', 0),
(84, 43, '2025-04-13 16:00:02', 0),
(85, 44, '2025-04-13 17:30:01', 0),
(86, 44, '2025-04-13 18:00:02', 0),
(87, 45, '2025-04-16 10:00:01', 1),
(88, 46, '2025-04-18 10:00:01', 1),
(89, 47, '2025-04-21 10:00:01', 1),
(90, 48, '2025-04-23 10:00:01', 1),
(91, 49, '2025-04-25 10:00:01', 1),
(94, 45, '2025-04-16 10:30:02', 1),
(95, 46, '2025-04-18 10:30:02', 1),
(96, 47, '2025-04-21 10:30:02', 1),
(97, 48, '2025-04-23 10:30:02', 1),
(98, 49, '2025-04-25 10:30:02', 1),
(101, 52, '2025-04-18 11:30:01', 0),
(102, 52, '2025-04-18 12:00:02', 0),
(103, 53, '2025-04-17 08:00:01', 1),
(104, 54, '2025-04-22 08:00:01', 1),
(105, 55, '2025-04-24 08:00:01', 1),
(106, 53, '2025-04-17 09:00:02', 1),
(107, 54, '2025-04-22 09:00:02', 1),
(108, 55, '2025-04-24 09:00:02', 1),
(109, 56, '2025-04-22 10:30:01', 0),
(110, 56, '2025-04-22 12:00:02', 0),
(111, 57, '2025-04-21 13:00:01', 0),
(112, 57, '2025-04-21 13:30:02', 0),
(113, 58, '2025-04-21 13:30:01', 0),
(114, 58, '2025-04-21 15:00:02', 0),
(115, 59, '2025-04-21 15:30:01', 0),
(116, 59, '2025-04-21 16:00:02', 0),
(117, 60, '2025-04-22 10:00:01', 0),
(118, 60, '2025-04-22 10:30:02', 0),
(119, 61, '2025-04-22 14:00:01', 0),
(120, 61, '2025-04-22 15:00:02', 0),
(121, 62, '2025-04-23 11:30:01', 0),
(122, 62, '2025-04-23 12:30:02', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `zinr_booking`
--
ALTER TABLE `zinr_booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `zinr_bookingdates`
--
ALTER TABLE `zinr_bookingdates`
  ADD PRIMARY KEY (`booking_dates_id`),
  ADD UNIQUE KEY `booking_id_dates` (`booking_id`,`booking_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `zinr_booking`
--
ALTER TABLE `zinr_booking`
  MODIFY `booking_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `zinr_bookingdates`
--
ALTER TABLE `zinr_bookingdates`
  MODIFY `booking_dates_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
